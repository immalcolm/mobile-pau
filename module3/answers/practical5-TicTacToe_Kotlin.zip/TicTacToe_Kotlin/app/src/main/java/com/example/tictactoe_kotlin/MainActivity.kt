package com.example.tictactoe_kotlin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.tictactoe_kotlin.ui.theme.TicTacToe_KotlinTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TicTacToe_KotlinTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TicTacToeGame()
                }
            }
        }
    }
}

@Composable
fun TicTacToeGame() {
    // State to track the state of each square in the Tic Tac Toe grid
    var squares by remember { mutableStateOf(List(9) { "" }) }

    // State to track whose turn it is (X or O)
    var isPlayerXTurn by remember { mutableStateOf(true) }

    // State to update the title text
    var titleText by remember { mutableStateOf("") }

    // Function to reset the game
    fun resetGame() {
        squares = List(9) { "" }
        isPlayerXTurn = true
        titleText = ""
    }

    // Function to check if a player has won based on the array, squares
    fun checkWin(): Boolean {
        // Check rows, if the rows character all matches
        for (i in 0 until 3) {
            if (squares[i * 3] == squares[i * 3 + 1] && squares[i * 3 + 1] == squares[i * 3 + 2] && squares[i * 3].isNotEmpty()) {
                return true
            }
        }

        // Check columns, if the columns character all matches
        for (i in 0 until 3) {
            if (squares[i] == squares[i + 3] && squares[i + 3] == squares[i + 6] && squares[i].isNotEmpty()) {
                return true
            }
        }

        // Check diagonals, if the left diagonal character all matches
        if (squares[0] == squares[4] && squares[4] == squares[8] && squares[0].isNotEmpty()) {
            return true
        }
        // if the right diagonal character all matches
        if (squares[2] == squares[4] && squares[4] == squares[6] && squares[2].isNotEmpty()) {
            return true
        }

        return false
    }

    // Column composable that fills the entire vertical space with padding
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Text indicating whose turn it is, centered horizontally
        Text(
            text = if (titleText.isNotEmpty()) titleText else if (isPlayerXTurn) "Player X's Turn" else "Player O's Turn",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 16.dp)
        )

        // LazyVerticalGrid to display the Tic Tac Toe grid with 3 columns
        LazyVerticalGrid(columns = GridCells.Fixed(3),
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
        ) {
            // Iterate through the indices of the Tic Tac Toe grid
            items((0..8).toList()) { index ->
                // Button for each square in the grid
                Button(
                    onClick = {
                        // Check if the square is empty before making a move
                        if (squares[index].isEmpty()) {
                            // Update the square based on the current player's turn
                            squares = squares.toMutableList().also {
                                it[index] = if (isPlayerXTurn) "X" else "O"
                            }

                            // Check if a player has won
                            if (checkWin()) {
                                // Handle the game-over state here
                                val winnerText = if (isPlayerXTurn) "Player X wins!" else "Player O wins!"
                                // Update the title text indicating the winner
                                titleText = winnerText
                            } else {
                                // Switch to the other player's turn
                                isPlayerXTurn = !isPlayerXTurn
                            }
                        }
                    },
                    // Button styling and appearance
                    modifier = Modifier
                        .size(50.dp)
                        .background(Color.Gray)
                        .padding(4.dp),
                    shape = RectangleShape,
                    colors = ButtonDefaults.buttonColors(
                        contentColor = Color.White
                    )
                ) {
                    // Display the content of the square (X, O, or empty)
                    Text(
                        text = squares[index],
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }

        // Reset button to reset the game
        Button(
            onClick = { resetGame() },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
        ) {
            Text(text = "Reset Game")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun TicTacToePreview() {
    TicTacToeGame()
}





