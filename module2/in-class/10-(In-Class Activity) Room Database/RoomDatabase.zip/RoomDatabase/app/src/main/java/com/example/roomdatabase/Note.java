package com.example.roomdatabase;

import androidx.room.PrimaryKey;
import androidx.room.Entity;

@Entity(tableName = "notes")
public class Note {
    @PrimaryKey
    private int id;
    private String title;
    private String content;

    public Note() {

    }
    public Note(int id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
    }
    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return this.id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return this.title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getContent() {
        return this.content;
    }
}
