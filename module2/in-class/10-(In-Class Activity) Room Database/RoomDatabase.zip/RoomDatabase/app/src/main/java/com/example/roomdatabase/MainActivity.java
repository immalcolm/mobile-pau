package com.example.roomdatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private EditText editTitle, editContent;
    private TextView displayTitle, displayContent;
    private Button saveButton, deleteButton;
    private NoteDatabase noteDatabase;
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        noteDatabase = Room.databaseBuilder(getApplicationContext(), NoteDatabase.class, "notes.db").build();
        NoteDao noteDao = noteDatabase.noteDao();
        editTitle = findViewById(R.id.editTitle);
        editContent = findViewById(R.id.editContent);
        displayTitle = findViewById(R.id.notesTitle);
        displayContent = findViewById(R.id.notesContent);
        saveButton = findViewById(R.id.saveButton);
        deleteButton = findViewById(R.id.deleteButton);
        executorService = Executors.newSingleThreadExecutor();


        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = editTitle.getText().toString();
                String content = editContent.getText().toString();
                Note note = new Note(1, title, content);
                executorService.execute(new InsertNoteRunnable(note));
                displayTitle.setText(title);
                displayContent.setText(content);

            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = 1;
                // Delete the note from the database
                executorService.execute(new DeleteNoteRunnable(id));
                displayTitle.setText("Notes Title");
                displayContent.setText("Set up your notes content!");
            }
        });

        executorService.execute((new DisplayNoteRunnable(1)));
    }

    private class InsertNoteRunnable implements Runnable {
        private final Note note;

        InsertNoteRunnable(Note note) {
            this.note = note;
        }

        @Override
        public void run() {
            noteDatabase.noteDao().insert(note);
        }
    }

    private class DeleteNoteRunnable implements Runnable {
        private final int noteId;

        DeleteNoteRunnable(int noteId) {
            this.noteId = noteId;
        }

        @Override
        public void run() {
            Note note = noteDatabase.noteDao().getNoteById(noteId);
            noteDatabase.noteDao().delete(note);
        }
    }

    private class DisplayNoteRunnable implements Runnable {
        private final int noteId;

        DisplayNoteRunnable(int noteId) {
            this.noteId = noteId;
        }

        @Override
        public void run() {
            Note note = noteDatabase.noteDao().getNoteById(noteId);
            if (note != null) {
                displayTitle.setText(note.getTitle());
                displayContent.setText(note.getContent());
            } else {
                displayTitle.setText("Notes Title");
                displayContent.setText("Set up your notes content!");
            }
        }
    }
}
