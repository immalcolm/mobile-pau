package com.example.firebase;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private EditText editTitle, editContent;
    private TextView displayTitle, displayContent;
    private Button saveButton, deleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTitle = findViewById(R.id.editTitle);
        editContent = findViewById(R.id.editContent);
        displayTitle = findViewById(R.id.notesTitle);
        displayContent = findViewById(R.id.notesContent);
        saveButton = findViewById(R.id.saveButton);
        deleteButton = findViewById(R.id.deleteButton);


        // Create reference to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://fir-activity-83e5a-default-rtdb.asia-southeast1.firebasedatabase.app/");
        DatabaseReference myRef = database.getReference("notes");

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = editTitle.getText().toString();
                String content = editContent.getText().toString();
                Note note = new Note(1, title, content);
                myRef.child(String.valueOf(note.getId())).setValue(note);
                displayTitle.setText(title);
                displayContent.setText(content);

            }
        });
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = 1;
                // Delete the note from the database
                myRef.child(String.valueOf(id)).removeValue();
                displayTitle.setText("Notes Title");
                displayContent.setText("Set up your notes content!");
            }
        });


        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    // Get the Note object from the snapshot
                    Note note = snapshot.getValue(Note.class);

                    // Display the retrieved data only for Note with id = 1
                    if (note != null && note.getId() == 1) {
                        displayTitle.setText(note.getTitle());
                        displayContent.setText(note.getContent());
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }
}