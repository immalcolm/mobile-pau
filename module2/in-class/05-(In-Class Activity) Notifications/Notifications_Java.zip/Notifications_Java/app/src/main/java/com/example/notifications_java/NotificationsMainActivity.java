package com.example.notifications_java;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class NotificationsMainActivity extends AppCompatActivity {

    // set the channel name
    public static final String CHANNEL_ID = "notification_channel";

    // create the notification channel
    private void createNotificationChannel() {
        // create the NotificationChannel, for API 26+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { // check if the API level > 26
            CharSequence name = "channel_name";
            String description = "channel_desc";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            // create NotificationChannel object
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // register the channel with the system
            // unable to change the importance or notification behaviour after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notifications_activity_main);
        // initiate the notification channel
        createNotificationChannel();

        // initialise the buttons
        Button notificationButton = (Button) findViewById(R.id.buttonNotification);
        Button toastButton = (Button) findViewById(R.id.buttonToast);

        // build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(NotificationsMainActivity.this, CHANNEL_ID)
                .setSmallIcon(R.drawable.icon_logo) // set icon
                .setContentTitle("New Notification!") // set title
                .setContentText("This is an example of a notification~"); // set text

        // set onClickListener to the notificationButton
        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NotificationManagerCompat notificationManager = NotificationManagerCompat.from(NotificationsMainActivity.this);
                int notificationId = 1;
                notificationManager.notify(notificationId, builder.build());
            }
        });

        // build the toast notification
        // set the duration of the toast notification to be short
        int duration = Toast.LENGTH_SHORT;
        // create the Toast object
        Toast toast = Toast.makeText(this, "New toast notification!", duration);

        toastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toast.show();
            }
        });

    }
}