package com.example.eventhandler_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class EventHandlerMainActivity extends AppCompatActivity {

    public static int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_handler_activity_main);

        // initialise all the buttons and the counter TextView
        Button addButton = (Button) findViewById(R.id.buttonAdd);
        Button minusButton = (Button) findViewById(R.id.buttonMinus);
        Button resetButton = (Button) findViewById(R.id.buttonReset);
        TextView counterTextView = (TextView) findViewById(R.id.counterTextView);

        // onClickListener for addButton
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // add one to the counter and update the counterTextView
                counter += 1;
                counterTextView.setText(String.valueOf(counter)); // convert to string
            }
        });

        // onClickListener for minusButton
        minusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // minus one to the counter and update the counterTextView
                counter -= 1;
                counterTextView.setText(String.valueOf(counter)); // convert to string
            }
        });

        // onClickListener for resetButton
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // reset the counter to 0 and update the counterTextView
                counter = 0;
                counterTextView.setText(String.valueOf(counter)); // convert to string
            }
        });
    }
}