package com.example.countdowntimer_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CountdownTimerMainActivity extends AppCompatActivity {

    public static Long timerMilliseconds;
    public static CountDownTimer countDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.countdown_activity_main);

        // initialise the displayTimer TextView
        TextView displayTimer = (TextView) findViewById(R.id.textViewSeconds);
        // initialise the Enter button
        Button enterButton = (Button) findViewById(R.id.buttonEnter);
        // initialise the Start button
        Button startButton = (Button) findViewById(R.id.buttonStart);

        // set an onClickListener get the input from the seconds TextView
        enterButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                // get the input from the seconds TextView
                EditText timerInput = (EditText) findViewById(R.id.editTextSeconds);
                String timerSeconds = timerInput.getText().toString();

                // display the timerSeconds in the TextView
                displayTimer.setText(timerSeconds);

                // convert to int data type
                Integer convertTimerSeconds = Integer.parseInt(timerSeconds);
                // convert to milliseconds and long data type
                timerMilliseconds = Long.valueOf(convertTimerSeconds * 1000);

                // setup the countDownTimer with timerMilliseconds and set the interval to 1s (1000ms)
                countDownTimer = new CountDownTimer(timerMilliseconds, 1000) {
                    @Override
                    public void onTick(long l) {
                        // convert the milliseconds back to seconds and convert it into a string
                        String seconds = Long.toString(l / 1000);
                        // update the TextView when counting down
                        displayTimer.setText(seconds);
                    }

                    @Override
                    public void onFinish() {
                        // set the duration of the toast notification to be short
                        int duration = Toast.LENGTH_SHORT;
                        // create the Toast object
                        Toast toast = Toast.makeText(CountdownTimerMainActivity.this, "Finish!", duration);
                        // display the toast
                        toast.show();
                    }
                };
            }
        });

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countDownTimer.start();
            }
        });

    }
}