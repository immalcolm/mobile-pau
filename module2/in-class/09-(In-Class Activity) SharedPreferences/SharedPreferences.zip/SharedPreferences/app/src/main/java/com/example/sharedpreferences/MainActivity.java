package com.example.sharedpreferences;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
public class MainActivity extends AppCompatActivity {
    private ConstraintLayout layout;
    private TextView textMessage;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layout = findViewById(R.id.layout);
        textMessage = findViewById(R.id.textMessage);
        Button buttonChangeColor = findViewById(R.id.buttonChangeColour);
        sharedPreferences = getSharedPreferences("ColourSchemePrefs", MODE_PRIVATE);

        buttonChangeColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeColourScheme();
            }
        });

        // Retrieve and set the stored background colour
        // When there is no background colour stored, White colour will be used
        int currentColour = sharedPreferences.getInt("backgroundColor", Color.WHITE);
        layout.setBackgroundColor(currentColour);
    }

    private void changeColourScheme() {
        // Retrieve the stored colour
        int currentColour = sharedPreferences.getInt("backgroundColor", Color.WHITE);

        // Two colours to use for the colour scheme
        int bgColour1 = Color.parseColor("#FFEED9");
        int bgColour2 = Color.parseColor("#E0F4FF");

        // Toggle between two colours (you can extend this to support more colours)
        if (currentColour == bgColour1) {
            currentColour = bgColour2;
        } else {
            currentColour = bgColour1;
        }

        // Apply the new colour
        layout.setBackgroundColor(currentColour);

        // Store the updated colour in SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("backgroundColor", currentColour);
        editor.apply();
    }
}