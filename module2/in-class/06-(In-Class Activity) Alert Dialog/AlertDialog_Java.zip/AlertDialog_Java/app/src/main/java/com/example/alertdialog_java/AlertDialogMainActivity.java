package com.example.alertdialog_java;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AlertDialogMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alert_dialog_activity_main);

        // initialise the "Answer" button and feeling TextView
        Button answerButton = (Button) findViewById(R.id.buttonAnswer);
        TextView feelingTextView = (TextView) findViewById(R.id.textViewFeeling);

        // set onClickListener for the "Answer" button
        answerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // initiate the AlertDialog.Builder
                AlertDialog.Builder builder = new AlertDialog.Builder(AlertDialogMainActivity.this);

                // add the regions to the AlertDialog
                builder.setMessage("How are you feeling today?")
                        .setTitle("Feelings today")
                        .setPositiveButton("Good", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // update the feelingTextView and set the colour
                                feelingTextView.setText("Good");
                                feelingTextView.setTextColor(Color.GREEN);

                            }
                        })
                        .setNegativeButton("Bad", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // update the feelingTextView and set the colour
                                feelingTextView.setText("Bad");
                                feelingTextView.setTextColor(Color.RED);
                            }
                        });

                // create the AlertDialog
                AlertDialog alert = builder.create();

                // show the AlertDialog
                alert.show();
            }
        });

    }
}