package com.example.recyclerview_java;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class RecyclerViewMainActivity extends AppCompatActivity {

    // create a String array for the tasks
    public static ArrayList<String> taskList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.task_activity_main);

        // link the RecyclerView in the View
        RecyclerView recyclerView = findViewById(R.id.TasksRecyclerView);

        // set the Layout manager which will tell the RecyclerView how to draw the list
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        // set default item animator for handling item change animations
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        // initialise the Adapter that was created and pass in the data
        CustomAdapter customAdapter = new CustomAdapter(taskList);
        // set the Adapter to the RecyclerView
        recyclerView.setAdapter(customAdapter);

        // initialise the Add button
        Button addButton = (Button) findViewById(R.id.buttonAdd);

        // when the add button is clicked, retrieve the task input from the user
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // get the task input from the user
                EditText taskInput = (EditText) findViewById(R.id.editTextTask);
                String task = taskInput.getText().toString();

                // add the task into the array
                taskList.add(task);

                // notify the adapter that the data has changed
                customAdapter.notifyDataSetChanged();

            }
        });

    }

}