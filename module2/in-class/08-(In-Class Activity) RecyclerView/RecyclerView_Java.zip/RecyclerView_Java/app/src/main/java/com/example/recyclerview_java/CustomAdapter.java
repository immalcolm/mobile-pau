package com.example.recyclerview_java;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {

    private ArrayList<String> localDataSet = new ArrayList<>();

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // initialise and pass in the ViewHolder that you have created
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_row_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        // get the element from the dataset in the current position
        // and replace the contents with the element inside you ViewHolder
        String item = localDataSet.get(position);
        holder.getTextView().setText(item);

    }

    @Override
    public int getItemCount() {
        return localDataSet.size();
    }

    // create the reference to the View components in the ViewHolder
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView textView;

        public ViewHolder(View view) {
            super(view);
            // define click listener for the ViewHolder's View component
            textView = (TextView) view.findViewById(R.id.taskViewText);
        }
        public TextView getTextView() {
            return textView;
        }
    }

    // initialise the dataset of the adapter
    public CustomAdapter(ArrayList<String> dataSet) {
        localDataSet = dataSet;
    }
}
