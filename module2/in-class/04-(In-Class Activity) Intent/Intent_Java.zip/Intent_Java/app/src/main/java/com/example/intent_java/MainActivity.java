package com.example.intent_java;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialise the Submit button
        Button submitButton = (Button) findViewById(R.id.buttonSubmit);

        // set an onClickListener and retrieve the name input
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // get the input from the name TextView
                EditText nameInput = (EditText) findViewById(R.id.editTextName);
                String name = nameInput.getText().toString();

                // create the Intent with the source and destination
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                intent.putExtra("Name", name); // pass in the name value and set the key as "Name"
                startActivity(intent); // start the activity

            }
        });

    }
}