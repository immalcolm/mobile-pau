package com.example.intent_java;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_2);

        // create an Intent object and retrieve the name value
        Intent intent = getIntent();
        String name = intent.getStringExtra("Name");

        // update the TextView with the name value
        TextView nameTextView = (TextView) findViewById(R.id.textViewName);
        String displayText = "Hello " + name + "! Hope you had a great day today!";
        nameTextView.setText(displayText);


    }
}
